
<?php
	
	require_once"../models/db_connect.php";	
		$err_mname="";
		$mname="";
		$err_director="";
		$director="";
		$err_cast="";
		$cast="";
		$err_month="";
		$month="";
		$err_day="";
		$day="";
		$err_year="";
		$year="";
		$err_category="";
		$category="";
		$err_genre="";
		$genre="";
		$err_imdb="";
		$imdb="";
		$err_description="";
		$description="";
		$err_img="";
		$img="";
		$has_error=false;
		$pending_message="";
		$cat=0;
		$gen=0;
		$date=0;
		$dayy=0;
		$yearr=0;
		$user=$_COOKIE["loggedinuser"];
		$monthlist=array("January","February","March","April","May","June","July","August","September","October","November","December");
		$categorylist=array("English","Hindi","Tamil","Telugu","Malayalam","Kannada","Korean","Spanish","Indonesia","China");
		$genrelist=array("Action","Thriller","Action,Romantic","Romantic","Romantic,Comedy","Drama,Action","Biography","Action,Comedy","Horror","Sci-fi");
		
		if(isset($_POST['login']))
		{
			
			if(empty($_POST['mname']))
			{
				$err_mname="*Movie Name Required";
				$has_error=true;
			}
			else
			{			
				$mname=htmlspecialchars($_POST['mname']);
				
			}
			if(empty($_POST['director']))
			{
				$err_director="*Director Name Required";
				$has_error=true;
			}
			else
			{			
				$director=htmlspecialchars($_POST['director']);
				
			}
			if(empty($_POST['cast']))
			{
				$err_cast="*Cast Required";
				$has_error=true;
			}
			else
			{			
				$cast=htmlspecialchars($_POST['cast']);
				
			}
			
			
			for($i=0;$i<count($monthlist);$i++){
			if($_POST['month']!=$monthlist[$i])
			{
				$err_month="*Month Required";
				$has_error=true;
			}
			else
			{			
				$month=htmlspecialchars($_POST['month']);
				$date=1;
				$err_month="";
				$has_error=false;
				break;
				
			}
			}
			
			
			for($i=1;$i<32;$i++){
			if($_POST['day']!=$i)
			{
				$err_day="*Day Required";
				$has_error=true;
			}
			else
			{			
				$day=htmlspecialchars($_POST['day']);
				$dayy=1;
				$err_day="";
				$has_error=false;
				break;
				
			}
			}
			
			
			for($i=1900;$i<2026;$i++){
			if($_POST['year']!=$i)
			{
				$err_year="*year Required";
				$has_error=true;
			}
			else
			{			
				$year=htmlspecialchars($_POST['year']);
				$yearr=1;
				$err_year="";
				$has_error=false;
				break;
				
			}
			}
			
			for($i=0;$i<count($categorylist);$i++)
			{
			if($_POST['category']!=$categorylist[$i])
			{
				$err_category="*Category Required";
				$has_error=true;
				
			}
			
			else
			{			
				$category=htmlspecialchars($_POST['category']);
				$cat=1;
				$err_category="";
				$has_error=false;
				break;
				
			}
			}
			for($i=0;$i<count($genrelist);$i++)
			{
			if($_POST['genre']!=$genrelist[$i])
			{
				$err_genre="*Genre Required";
				$has_error=true;
			}
			else
			{			
				$genre=htmlspecialchars($_POST['genre']);
				$gen=1;
				$err_genre="";
				$has_error=false;
				break;
			}
			}
			if(empty($_POST['imdb']))
			{
				$err_imdb="*IMDB Required";
				$has_error=true;
			}
			
			else
			{
				
				$imdb=htmlspecialchars($_POST['imdb']);
			}
			if(empty($_POST['description']))
			{
				$err_description="*Description Required";
				$has_error=true;
			}
			else
			{
				$description=htmlspecialchars($_POST['description']);
				
			}
			
			
				
			

			if(!$has_error){
				
				if($category=='Hindi'){
					$mid=0;
				}
				else if($category=='English'){
					$mid=1;
				}
				else if($category=='Tamil'){
					$mid=2;
				}
				else if($category=='Telugu'){
					$mid=3;
				}
				else if($category=='Malayalam'){
					$mid=4;
				}
				else if($category=='Kannada'){
					$mid=5;
				}
				else if($category=='Korean'){
					$mid=6;
				}
				else if($category=='Spanish'){
					$mid=7;
				}
				else if($category=='Indonesia'){
					$mid=8;
				}
				else if($category=='China'){
					$mid=9;
				}
				$filename=$_FILES['fileToUpload']['name'];
				$target_dir='Photo/'.$filename;
				$extension=pathinfo($filename,PATHINFO_EXTENSION);
				$file=$_FILES['fileToUpload']['tmp_name'];
				
				
				
				if(move_uploaded_file($file,$target_dir)){
					
					if($_COOKIE['youare']=='1'){
					$query="INSERT INTO addreview (uploader,mid,name, director, cast, month, day, year, category, genre, imdb,img,description) 
					VALUES ('$user','$mid','$mname', '$director', '$cast', '$month', '$day', '$year', '$category', '$genre', '$imdb', '$filename','".$description."')";
					$users=execute($query);
					header("Location:movies.php");
					}
					else{
					$qury="INSERT INTO pendingreview (uploader,mid,name, director, cast, month, day, year, category, genre, imdb,img,description,date,time)
					VALUES ('$user','$mid','$mname', '$director', '$cast', '$month', '$day', '$year', '$category', '$genre', '$imdb', '$filename','$description',CURDATE(),LOCALTIME())";
					$user=execute($qury);
					$pending_message="Your Review is Pending";
					
					$err_mname="";
					$mname="";
					$director="";
					$cast="";
					$month="Month";
					$day="Day";
					$year="Year";
					$category="Choose a Category";
					$genre="Choose a Genre";
					$imdb="";
					$description="";
					$img="";
					}
					
					
					
				}
			}
		}
		?>
