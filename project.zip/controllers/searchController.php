<?php

	session_start();
	$admin=0;
	require_once "../models/db_connect.php";
	
	$has_error=false;
	if(!isset($_COOKIE['loggedinuser']))
	{
		header("Location:login.php");
		$has_error=true;
	}
		
	
	
	


$text="";
if(isset($_POST['searchBtn']))
		{
			
			if(empty($_POST['searchText']))
			{
				$has_error=true;
			}
			else{
				$text=htmlspecialchars($_POST['searchText']);
			}
			if(!$has_error){
				
				header("Location:searchedmovies.php?q=$text");
				
			}
		}
?>
