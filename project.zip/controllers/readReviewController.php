

<?php
	
	require_once "../models/db_connect.php";
	
	$admin=0;
	$Name="";
	$Director="";
	$Cast="";
	$month="";
	$day="";
	$year="";
	$Category="";
	$Genre="";
	$IMDb="";
	$Description="";
	
	$mid="";
					$mname="";
					$director="";
					$cast="";
					$month="";
					$day="";
					$year="";
					$category="";
					$genre="";
					$imdb="";
					$description="";
	
	$has_error=false;
	
	if(!isset($_COOKIE['loggedinuser']))
	{
		header("Location:login.php");
		$has_error=true;
	}
	$user=$_COOKIE['loggedinuser'];
	$query="SELECT * FROM addreview ORDER BY id DESC";
	$commentquery="SELECT * FROM comment ORDER BY id DESC";
	$favmoviequery="SELECT * FROM favmovie";
	$pendingquery="SELECT * FROM pendingreview";
	
	$reviews=get($query);
	$favrev=get($query);
	$getcomment=get($commentquery);
	$getfavmovie=get($favmoviequery);
	$getpendingreview=get($pendingquery);
	
	$pid=$_GET['mid'];
	
	
	
	$comment="";
	$err_comment="";
	
	if(isset($_POST['postcomment'])){
		if(empty($_POST['comment'])){
			$err_comment="*Comment Required";
			$has_error=true;
		}
		else{
			$comment=htmlspecialchars($_POST['comment']);
		}
		if(!$has_error){
			$query="INSERT INTO comment (mid,comment,user) 
			VALUES ('$pid','$comment', '$user')";
		
			$com=execute($query);
			
			header("Location:readreview.php?mid=$pid");
			
		}
		
	}
	
		
			if(mysqli_num_rows($favrev) > 0)
			{
				
				while($ro = mysqli_fetch_assoc($favrev))
				{
					
					if($ro["id"]==$pid){
					
					
					
					$moviename=$ro["name"];
					
					
				}
				}
			}
	
	
	
	
	
	
	if(isset($_POST['favAreview'])){
	
	$favmoviequery="INSERT INTO favmovie (musername,fmid,mname,date,time) VALUES('$user','$pid','$moviename',CURDATE(),LOCALTIME())";
	$addfavreview=execute($favmoviequery);
	header("Location:readreview.php?mid=$pid");
		
	}
	if(isset($_POST['favRreview'])){
	
	$favquery="DELETE FROM favmovie WHERE musername='$user' AND fmid='$pid' ";
	$removefavreview=execute($favquery);
	header("Location:readreview.php?mid=$pid");
		
	}
	
	if(isset($_POST['approve'])){
	
				if(mysqli_num_rows($getpendingreview) > 0)
			{
				
				while($rows = mysqli_fetch_assoc($getpendingreview))
				{
					
					if($rows["id"]==$pid){
					$uploader=$rows['uploader'];
					$mid=$rows["mid"];
					$mname=$rows["name"];
					$director=$rows["director"];
					$cast=$rows["cast"];
					$month=$rows["month"];
					$day=$rows["day"];
					$year=$rows["year"];
					$category=$rows["category"];
					$genre=$rows["genre"];
					$imdb=$rows["imdb"];
					$filepath = $rows["img"];
					$description=$rows["description"];
					
					}
				}
			}
	
	$qury="INSERT INTO addreview (uploader,mid,name, director, cast, month, day, year, category, genre, imdb,img,description) 
					VALUES ('$uploader','$mid','$mname', '$director', '$cast', '$month', '$day', '$year', '$category', '$genre', '$imdb', '$filepath','".$description."')";
	$user=execute($qury);
	$remquery="DELETE FROM pendingreview WHERE id='$pid'";
	$removereview=execute($remquery);
	header("Location:pendingAndFavReview.php?id=$user");
		
	}
	if(isset($_POST['reject'])){
	
	$remquery="DELETE FROM pendingreview WHERE id='$pid'";
	$removereview=execute($remquery);
	header("Location:pendingAndFavReview.php?id=$user");
		
	}
	
?>