<div class="login-box">
				<center><span style="color:Yellow"><?php echo $congratulation;?></span></center>
				<table>
					
					<tr>
						<td>
							<p>New Password:</p>
						</td>
					</tr>
					<tr>
						<td>
							<input type="password" name="newpass" value="<?php echo $newpass;?>" placeholder="Enter New Password">
							
						</td>
						<td>
							
							<small><small><span style="color:red"><?php echo $err_newpass;?></span></small></small>
						</td>
					</tr>
					<tr>
						<td>
							<p>Confirm Password:</p>
						</td>
					</tr>
					<tr>
						<td>
							<input type="password" name="confirmpass" value="<?php echo $confpass;?>" placeholder="Confirm Password">
							
						<td>
							
							<small><small><span style="color:red"><?php echo $err_confpass;?></span></small></small>
						</td>
					</tr>
					<tr>
						<td>
						<input type="submit" name="login" value="Submit">
						</td>
					</tr>
				
				</table>
				</div>