
<table>
		<tr>
			<td>
				<DIV class="welcome">
				<?php $user=$_COOKIE["loggedinuser"]?>
				<b>Welcome </b><a href="profile.php?id=<?php echo $user ?>" style="text-decoration: none;"><b id="user"><?php echo $user?></b></a><b>!</b>
				</td>
				<td>
				</DIV>
				<DIV class="logout"><a style="text-decoration: none;"href="login.php"><b id="loghov">Logout</b></a>
				</DIV>
			</td>
		</tr>
	</table>
	
	
	
	
	
	
<html>
	<head>
	
		<script>
			function search()
			{
				var xhttp = new XMLHttpRequest();
				
				var key = document.getElementById('searchTF').value;
				
				xhttp.onreadystatechange=function()
				{
					if(xhttp.readyState == 4 && xhttp.status == 200)
					{
						document.getElementById('result').innerHTML = xhttp.responseText;
					}
				}
				xhttp.open("GET","db.php?key="+key,true);
				xhttp.send();
			}
		</script>
	</head>
	
	<body>
		<div class="search">
		<input type='text' class="search-text" onkeyup='search()' autocomplete='off' name='searchTF' id='searchTF' placeholder='Search By Movie Name'>
		</div>	
	
		<br>
		
			<div  id="result"> </div>
		 
		
	</body>
</html>
	