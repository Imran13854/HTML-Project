<?php
	require_once"../models/db_connect.php";
		
		
		$err_newpass="";
		$newpass="";
		$err_confpass="";
		$confpass="";
		$has_error=false;
		$congratulation="";
		$id=1;
		if(isset($_POST['Gohome']))
		{
			header("Location:login.php");
		}
		
		if(isset($_POST['login']))
		{
			
			
			
			if(empty($_POST['newpass']))
			{
				$err_newpass="*Password Required";
				$has_error=true;
			}
			else
			{
				$newpass=htmlspecialchars($_POST['newpass']);
				$newpass=$_POST['newpass'];
				
				if (strlen($newpass)>=8){
				
					
				}
				else{
					$err_newpass="*Password must contain more than 8 char or digits";
					$has_error=true;
				}
				
			}
			if(empty($_POST['confirmpass']))
			{
				$err_confpass="*Password Required";
				$has_error=true;
			}
			else
			{
				$confpass=htmlspecialchars($_POST['confirmpass']);
				$confpass=$_POST['confirmpass'];
				
				if ($confpass == $newpass){
				
					
				}
				else{
					$err_confpass="*Password doesn't match";
					$has_error=true;
				}
				
			}
			
			if(!$has_error){
				
			 $newpass=md5($newpass);
			 $data="Update login SET password='$newpass' where username='$username'";
			
			$log=execute($data);
			
			$congratulation="Password Succuessfully Updated";
			
			
			
			
			$err_newpass="";
			$newpass="";
			$err_confpass="";
			$confpass="";
			
			}
			
			
		}
?>