<?php
			
			if(mysqli_num_rows($getpendingreview) > 0)
			{
				
				while($rows = mysqli_fetch_assoc($getpendingreview))
				{
					
					if($rows["id"]==$pid){
					
					$mid=$rows["mid"];
					$mname=$rows["name"];
					$director=$rows["director"];
					$cast=$rows["cast"];
					$month=$rows["month"];
					$day=$rows["day"];
					$year=$rows["year"];
					$category=$rows["category"];
					$genre=$rows["genre"];
					$imdb=$rows["imdb"];
					$description=$rows["description"];
					
					
					$filepath = 'Photo/' . $rows['img'];
					$moviename=$rows["name"];
					
					echo "<div class='pic'>";
					echo "<center>";
					echo "<img src=$filepath width='300px' height='300px'>"."<br>".
					"<p>".$moviename."</p>".
					
					"</center>";
					echo "</div>";
					
					if($_COOKIE['youare']=='1'){
						echo "<center>";
					echo "<div class='favbtn'>";
						echo "<input   class='rbtn'  name='approve'  id='app' type='submit' value='Approve Review'>";
						echo "<input   class='abtn'  name='reject'  id='rej' type='submit' value='Reject Review'>"	.
						"</div>";
					echo "</center>";
					echo "<br><br>";
					}
			

					
					
					echo "<div class='point'>";
					echo "<table>";
			
					echo "<tr>";
					echo "<td class='name'>"."Name"."</td>";
					echo "<td class='disname'>".": ".$rows["name"]."</td>";
					echo "</tr>";
					
					
					
					echo "<tr>";
					echo "<td class='name'>"."Director"."</td>";
					echo "<td class='disname'>".": ".$rows["director"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"."Cast"."</td>";
					echo "<td class='disname'>".": ".$rows["cast"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"."Relase Date"."</td>";
					echo "<td class='disname'>".": ".$rows["month"]." ".$rows["day"].",".$rows["year"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"."Category"."</td>";
					echo "<td class='disname'>".": ".$rows["category"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"."Genre"."</td>";
					echo "<td class='disname'>".": ".$rows["genre"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"."IMDB"."</td>";
					echo "<td class='disname'>".": ".$rows["imdb"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td valign='top' class='name'>"."Description"."</td>";
					echo "<td class='disname'>".":".$rows["description"]."</td>";
					echo "</tr>";
					echo "</table>";
					
					echo "</div>";
					
					
					
					}
					
				}
			}
		
		?>