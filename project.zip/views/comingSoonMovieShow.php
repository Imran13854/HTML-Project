<?php 

			if($_COOKIE['youare']=='1')
			{?>
				<div class="login-box">
				
				
					
					<center><h1>Add Coming Soon Movies</h1></center>
						
					<center><span style="color:red;"><h2><?php echo $success;?></h2></span></center>	
				<table>
					<tr>
						<td align="left"> 
						<p>Movie Name</p>  
						</td>
						<td>
							<input type="text" style="width:580px;" name="mname" value="<?php echo $mname;?>" placeholder="Enter Movie name">
						</td>
						<td>
							<small><span style="color:yellow"><?php echo $err_mname;?></span></small>
						</td>
					</tr>
					<tr>
						<td align="left"> 
						<p>Director</p>  
						</td>
						<td>
							<input type="text" style="width:580px;" name="director" value="<?php echo $director;?>" placeholder="Enter Director name">
						</td>
						<td>
							<small><span style="color:yellow"><?php echo $err_director;?></span></small>
						</td>
					</tr>
					
					<tr>
						<td align="left">
						<p>Cast</p>
						</td>
						<td>
						<input type="text" style="width:580px;" name="cast" value="<?php echo $cast;?>" placeholder="Enter Movie Cast">
						</td>
						<td>
							<small><span style="color:yellow"><?php echo $err_cast;?></span></small>
						</td>
					</tr>
					<tr>
						<td align="left">
							<p>Release Date</p>
						</td>
						<td>
						<select name = "month" style="height: 25px;width: 105px">
							<option>Month</option>
							<?php 
								if($date==1){ ?>
								<option selected="true">
								
								<?php echo $month;?></option>
								<?php } ?>
							<?php
							for($month = 0; $month < 12; $month++){
								echo"<option value = '".$monthlist[$month]."'>".$monthlist[$month]."</option>";
							}
						    ?>
						
						
						</select>
						<select name = "day" style="height: 25px;width: 105px">
							<option>Day</option>
							<?php 
								if($dayy==1){ ?>
								<option selected="true">
								
								<?php echo $day;?></option>
								<?php } ?>
							<?php
							for($day = 1; $day <= 31; $day++){
								echo "<option value = '".$day."'>".$day."</option>";
							}
							?>
						</select>
						<select name = "year" style="height: 25px;width: 105px">
							<option>Year</option>
							<?php 
								if($yearr==1){ ?>
								<option selected="true">
								
								<?php echo $year;?></option>
								<?php } ?>
					
							<?php
							for($year = 2030; $year >= 2020; $year--){
								echo "<option value = '".$year."'>".$year."</option>";
							}
							?>
						</select>	
						</td>
					<td>
						<small><span style="color:red"><?php echo $err_month;?></span></small>
						<small><span style="color:blue"><?php echo $err_day;?></span></small>
						<small><span style="color:orange"><?php echo $err_year;?></span></small>
					</td>
					</tr>
					<tr>
						<td>
							<p>Category</p>
						</td>
						<td>
							<select name="category">
								
								<option selected="true">Choose a Category</option>
								<?php 
								if($cat==1){ ?>
								<option selected="true">
								
								<?php echo $category;?></option>
								<?php } ?>
								<option>English</option>
								<option>Hindi</option>
								<option>Tamil</option>
								<option>Telugu</option>
								<option>Malayalam</option>
								<option>Kannada</option>
								<option>Korean</option>
								<option>Spanish</option>
								<option>Indonesia</option>
								<option>China</option>
							</select>
						</td>
						<td>
							<small><span style="color:yellow"><?php echo $err_category;?></span></small>
						</td>

					</tr>
					<tr>
						<td>
							<p>Genre</p>
						</td>
						<td>
							<select name="genre"  style="width: 172px;">
							
								<option selected="true">Choose a Genre</option>
								<?php 
								if($gen==1){ ?>
								<option selected="true">
								
								<?php echo $genre;?></option>
								<?php } ?>
								<option>Action</option>
								<option>Thriller</option>
								<option>Action,Romantic</option>
								<option>Romantic</option>
								<option>Romantic,Comedy</option>
								<option>Drama,Action </option>
								<option>Biography</option>
								<option>Action,Comedy</option>
								<option>Horror</option>
								<option>Sci-fi</option>
							</select>
						</td>
						<td>
							<small><span style="color:yellow"><?php echo $err_genre;?></span></small>
						</td>
					</tr>
					
					<tr>
						<td>
							<p>Cover Photo</p>
						</td>
						<td>
							<input style="color:green; width:580px;" type="file" name="fileUpload">
						</td>
						<td>
							<small><span style="color:yellow"><?php echo $err_img;?></span></small>
						</td>
					</tr>
					
				</table>
						<center><input type="submit" name="login" value="Submit"></center>
						
					
				</div>
				
		<?php	} ?>
		



<?php 
	if($_COOKIE['youare']=='1')
	{		
	echo "<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
	<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>";
	} 
	else
	{
	echo "<br><br><br><br><br><br><br><br>";
	echo "<center>";
		echo "<h1 id='h'>Coming Soon Movies</h1>";
	echo "</center>";
	}
?>

<?php
	$count=0;
	require_once "../models/db_connect.php";
	$query="SELECT * FROM comingsoon ORDER BY id DESC";
	$reviews=get($query);
			
			if(mysqli_num_rows($reviews) > 0)
			{
				echo "<table>";
				echo "<tr>";
				while($rows = mysqli_fetch_assoc($reviews))
				{
					
					
					$filepath = 'Photo/' . $rows['img'];
					$moviename=$rows["name"];
					$mid=$rows["id"];
					
					
					echo "<td>";
					echo "<center>";
					echo "<div class='dpic'>";
					
					echo "<a href='comingsoonSingleMovie.php?id=$mid'>"."<img src=$filepath width='200px' height='200px'></a>".
					"<p>".$moviename."</p>";
					
					
					echo "</div>";
					echo "</center>";
					echo "</td>";
					$count=$count+1;
					if($count==5){
						
						echo "<tr>";
						
						$count=0;
					}
					
					
				}
				echo "</tr>";
					echo "</table>";
			}
			?>
		<br> <br> <br> <br> <br> 