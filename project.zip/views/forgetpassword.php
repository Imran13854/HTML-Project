<?php 
require_once"../models/db_connect.php";
$email="";
$err_msg="";
$has_err=false;
if(isset($_POST['back'])){
	header("Location:login.php");
}
if(isset($_POST['submit'])){
	if(empty($_POST['email'])){
		$has_err=true;
	}
	else{
		$email=htmlspecialchars($_POST['email']);
	}
	if(!$has_err){
		$query="SELECT email,username FROM signup where email='$email'";
					
		$result=get($query);
		if(mysqli_num_rows($result) > 0)
		{
			$row=mysqli_fetch_assoc($result);
			$id=$row['username'];
			header("Location:changepass.php?id=$id");
		}
		else{
			$err_msg="Invalid Email";
		}
	}
	
}

?>


<html>
	<head>
	
	<link rel="stylesheet" type="text/css" href="CSSS/home.css">
	</head>
	<body>
	<header>
		<form action="" method="POST">
		<div class="error">
		<?php echo $err_msg; ?>	
		</div>		
		<div class="EmailBox">
		
			<input type="text"  name="email" placeholder="Enter Your Email">
			<input type="submit" name="submit" value="GO ">
			<input type="submit" name="back" value="Back">
		</div>
		
		</form>
		</header>
	</body>
<html>