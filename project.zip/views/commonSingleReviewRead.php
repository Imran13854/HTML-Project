	

<?php
				
			if(mysqli_num_rows($reviews) > 0)
			{
				
				while($rows = mysqli_fetch_assoc($reviews))
				{
					
					if($rows["id"]==$pid){
					
					
					$filepath = 'Photo/' . $rows['img'];
					$moviename=$rows["name"];
					$uploader=$rows['uploader'];
					
					echo "<div class='pic'>";
					echo "<center>";
					echo "<img src=$filepath width='300px' height='300px'>"."<br>".
					"<p>".$moviename."</p>".
					
					
					"</center>";
					echo "</div>";
					
					if($_COOKIE['youare']=='1'){
					echo "<div class='editbtn'>";
					echo "<ul>".
							
								"<li class='btn'>"."<a href='editreview.php?mid=$pid'>"."Edit Review"."</a>"."</li>".
							"</ul>".
					"</div>";
					echo "<br><br><br>";
					}
			else{
				$no_row=0;		
				if(mysqli_num_rows($getfavmovie) > 0)
				{
					
					while($row = mysqli_fetch_assoc($getfavmovie))
					{
						
						if($row["fmid"]==$pid && $row["musername"]==$user){	
							
						echo "<div class='favbtn'>";
						echo "<input   class='rbtn'  name='favRreview'  id='addfav' type='submit' value='Remove From Favorite'>".
								
						"</div>";
						echo "<br>";
						
						$no_row=0;
						break;
						}
						else
						{
							
						$no_row=1;
						
						}
						
					}
				}
				else
						{
							
						$no_row=1;
						
						}
					if($no_row==1){
					echo "<div class='afavbtn'>";
						echo "<input   class='abtn'  name='favAreview'  id='addfav' type='submit' value='Add To Favorite'>".
								
						"</div>";
						echo "<br>";
					}

								
			}

					
		
					
					
					
					echo "<div class='point'>";
					echo "<table>";
					
					echo "<tr>";
					echo "<td class='name'>"."Name"."</td>";
					echo "<td class='disname'>".": ".$rows["name"]."</td>";
					echo "</tr>";
					
					
					
					echo "<tr>";
					echo "<td class='name'>"."Director"."</td>";
					echo "<td class='disname'>".": ".$rows["director"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"."Cast"."</td>";
					echo "<td class='disname'>".": ".$rows["cast"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"."Relase Date"."</td>";
					echo "<td class='disname'>".": ".$rows["month"]." ".$rows["day"].",".$rows["year"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"."Category"."</td>";
					echo "<td class='disname'>".": ".$rows["category"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"."Genre"."</td>";
					echo "<td class='disname'>".": ".$rows["genre"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"."IMDB"."</td>";
					echo "<td class='disname'>".": ".$rows["imdb"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td valign='top' class='name'>"."Description"."</td>";
					echo "<td class='disname'>".":".$rows["description"]."</td>";
					echo "</tr>";
					
					echo "<center>
						  
								<b>Uploaded By $uploader</b>
							
							</center>
					";
					echo "</table>";
					
					echo "</div>";
					
					
					
					}
					
				}
			}
		
		?>
			
					
		<br> <br> <br> <br> <br> <br> <br> <br>
		<div class="comm">Comments</div>
		<?php
			
				
				
			if(mysqli_num_rows($getcomment) > 0)
			{
				
				while($rows = mysqli_fetch_assoc($getcomment))
				{
					
				
					if($rows["mid"]==$pid){
					$user=$rows["user"];
					echo "<div class='comments'>";
					echo "<table>";
			
					echo "<tr>";
					
					echo "<td class='name'>"."<a href='profile.php?id=$user'>".$user."</a>"."</td>";
					echo "</tr>";
					
					
					
					echo "<tr>";
					
					echo "<td class='disname'>"."- ".$rows["comment"]."</td>";
					echo "</tr>";
					
					
					echo "</table>";
					
					echo "</div>";
					
					
					}
					
					
				}
			}
		
	?>				
		
		<div class="comment">
		
			<table>
				<tr>
					<td>
						<textarea style=" resize: none; width:880px; height:60px;"  name="comment" placeholder="Write Comment..."></textarea>
						
						
					</td>
					<td valign="bottom">
						<input type="submit" style="width:100px; height:30px;" name="postcomment" value="Post">
					</td>
				</tr>
				<tr>
					<td>
					<small><span style="color:red"><?php echo $err_comment;?></span></small>
					</td>
				</tr>
			</table>
			
		
		</div>
				