<?php 
require_once "../controllers/allReviewController.php";
require_once "../controllers/searchController.php";
?>
<html>

	<title>Movies</title>
	
	<head>
		<link rel="stylesheet" type="text/css" href="CSSS/movie.css">
		<link rel="stylesheet" type="text/css" href="CSSS/commonCategory.css">
		<script src="https://kit.fontawesome.com/1e099de9d8.js"></script>
	</head>
	
	
	<body>
	<header>
		
		<form  action="" method="POST">
		<?php require_once"../controllers/userCheck.php"?>
			<center>
			<h1>Reviews</h1>
			</center>
						
						<div class="button">
							<ul>
							
								<li class="inactive"><a href="Homepage.php">Home</a></li>
								<li class="active"><a href="movies.php">Movies</a></li>
								
								<li class="inactive"><a href="intheater.php">In Theaters</a></li>
								<li class="inactive"><a href="comingsoon.php">Coming soon</a></li>
								<li class="inactive"><a href="bestmovie.php">Best Movies</a></li>
								<?php
								if($_COOKIE['youare']=='1'){?>
								<li class="inactive"><a href="addadmin.php">Add Admin</a></li>
								
								
								<?php } ?>
								<li class="inactive"><a href="addreview.php">Add Reviews</a></li>
								<li class="inactive"><a href="about.php">About</a></li>
							</ul>
						</div>
						
								
				<?php require_once"category.php"?>
				
					
		
		<br> <br> <br> <br> <br> <br> <br> <br>
		
		<?php
			
				if($pid==0){
					$cat="Hindi";
				}	
				else if($pid==1){
					$cat="English";
				}
				else if($pid==2){
					$cat="Tamil";
				}
				else if($pid==3){
					$cat="Telugu";
				}
				else if($pid==4){
					$cat="Malayalam";
				}
				else if($pid==5){
					$cat="Kannada";
				}
				else if($pid==6){
					$cat="Korean";
				}
				else if($pid==7){
					$cat="Spanish";
				}
				else if($pid==8){
					$cat="Indonesia";
				}
				else if($pid==9){
					$cat="China";
				}
				echo "<center>";
				echo "<h1>".$cat." Movie Review"."</h1>";
				echo "</center>";
			if(mysqli_num_rows($reviews) > 0)
			{
				
				while($rows = mysqli_fetch_assoc($reviews))
				{
					
					if($rows["mid"]==$pid){
					
					
					$filepath = 'Photo/' . $rows['img'];
					$moviename=$rows["name"];
					$id=$rows['id'];
					echo "<table>";
					echo "<tr>";
					
					echo "<td  class='images'>"."<a href='readreview.php?mid=$id'>"."<img src=$filepath width='200px' height='200px'>"."</a>"."<br>".
					"<center>"."<p>".$moviename."</p>"."</center>"."</td>";
					
					
					echo "<td>";
					echo "<div class='point'>";
					echo "<table>";
			
					echo "<tr>";
					echo "<td class='name'>"."Name"."</td>";
					echo "<td class='disname'>".": ".$rows["name"]."</td>";
					echo "</tr>";
					
					
					
					echo "<tr>";
					echo "<td class='name'>"."Director"."</td>";
					echo "<td class='disname'>".": ".$rows["director"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"."Cast"."</td>";
					echo "<td class='disname'>".": ".$rows["cast"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td valign='top' class='name'>"."Relase Date"."</td>";
					echo "<td valign='top' class='disname'>".": ".$rows["month"]." ".$rows["day"].",".$rows["year"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"."Category"."</td>";
					echo "<td class='disname'>".": ".$rows["category"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"."Genre"."</td>";
					echo "<td class='disname'>".": ".$rows["genre"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"."IMDB"."</td>";
					echo "<td class='disname'>".": ".$rows["imdb"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td valign='top' class='name'>"."Description"."</td>";
					echo "<td class='disname'>".":".$rows["description"]."</td>";
					echo "</tr>";
					echo "</table>";
					
					echo "</div>";
					echo "</td>";
					echo "</tr>";
					echo "</table>";
					
					}
					
				}
			}
		
		?>
			
					
				
		
		</form>
		</header>
	</body>



</html>