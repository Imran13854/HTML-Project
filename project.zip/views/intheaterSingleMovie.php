<?php 
$pid=$_GET['id'];
require_once "../controllers/intheaterController.php";
require_once "../controllers/searchController.php";

?>
<html>

	<title>Movies</title>
	<head>
		<link rel="stylesheet" type="text/css" href="CSSS/intheater.css">
		<link rel="stylesheet" type="text/css" href="CSSS/commonCategory.css">
		<script src="https://kit.fontawesome.com/1e099de9d8.js"></script>
		
	
	</head>
	
	
	
	
	<body>
		<header>
		
		<form action="" method="post" enctype="multipart/form-data">
		<?php require_once "../controllers/userCheck.php"?>	
		<center>
			<h1 id="h">In Theaters Movies</h1>
		</center>
						<div class="button">
							<ul>
								<li class="inactive"><a href="Homepage.php">Home</a></li>
								<li class="inactive"><a href="movies.php">Movies</a></li>
								
								<li class="active"><a href="intheater.php">In Theaters</a></li>
								<li class="inactive"><a href="comingsoon.php">Coming soon</a></li>
								<li class="inactive"><a href="bestmovie.php">Best Movies</a></li>
								<?php
								if($_COOKIE['youare']=='1'){?>
								<li class="inactive"><a href="addadmin.php">Add Admin</a></li>
								
								
								<?php } ?>
								<li class="inactive"><a href="addreview.php">Add Reviews</a></li>
								<li class="inactive"><a href="about.php">About</a></li>
							</ul>
						</div>
				
				
				
				
				
			
		

<br> <br> <br> 

<?php
		require_once "../models/db_connect.php";
	
	$query="SELECT * FROM intheater ORDER BY id DESC";
	$reviews=get($query);
			
			if(mysqli_num_rows($reviews) > 0)
			{
				
				while($rows = mysqli_fetch_assoc($reviews))
				{
					
					if($rows["id"]==$pid){
					$filepath = 'Photo/' . $rows['img'];
					$moviename=$rows["name"];
					
					
					echo "<div class='pic'>";
					echo "<center>";
					echo "<img src=$filepath width='300px' height='300px'>"."<br>".
					"<p>".$moviename."</p>".
					
					
					"</center>";
					echo "</div>";
					
					
					if($_COOKIE['youare']=='1'){
					echo "<div class='editbtn'>";
					echo "<input   class='btn'  name='remove'  id='reremove' type='submit' value='Remove From ComingSoon'>".
					"</div>";
					echo "<br>";
					}
			
					
					
					
					
					
			
					echo "<div class='point'>";
					echo "<table>";
					
					echo "<tr>";
					echo "<td class='name'>"."Name"."</td>";
					echo "<td class='disname'>".": ".$rows["name"]."</td>";
					echo "</tr>";
					
					
					
					echo "<tr>";
					echo "<td class='name'>"."Director"."</td>";
					echo "<td class='disname'>".": ".$rows["director"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"."Cast"."</td>";
					echo "<td class='disname'>".": ".$rows["cast"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"."Relase Date"."</td>";
					echo "<td class='disname'>".": ".$rows["month"]." ".$rows["day"].",".$rows["year"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"."Category"."</td>";
					echo "<td class='disname'>".": ".$rows["category"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"."Genre"."</td>";
					echo "<td class='disname'>".": ".$rows["genre"]."</td>";
					echo "</tr>";
					
					
					
					echo "</table>";
					
					echo "</div>";
					
					echo "<br><br>";
					}
					}
					
				}
			
		
		?>
				</form>
		</header>
	</body>



</html>