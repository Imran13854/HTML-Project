<?php
	$username=$_GET['id'];
	require_once "../controllers/changePasswordController.php";
	session_start();
	$admin=0;
	require_once "../models/db_connect.php";
	
	$has_error=false;
	if(!isset($_COOKIE['loggedinuser']))
	{
		
		$has_error=true;
	}
		
	
	
?>

<html>
	<head>
		<link rel="stylesheet" type="text/css" href="CSSS/changepass.css">
		<script src="https://kit.fontawesome.com/1e099de9d8.js"></script>
	</head>
	<body>
		<header>
		
		<form  action="" method="POST">
		
		<?php
				if(!$has_error){
		require_once "../controllers/userCheck.php"?>
			<center>
			<h1>Profile</h1>
			</center>
						
						<div class="button">
							<ul>
							
								<li class="active"><a href="Homepage.php">Home</a></li>
								<li class="inactive"><a href="movies.php">Movies</a></li>
								
								<li class="inactive"><a href="intheater.php">In Theaters</a></li>
								<li class="inactive"><a href="comingsoon.php">Coming soon</a></li>
								<li class="inactive"><a href="bestmovie.php">Best Movies</a></li>
								<?php
								if($_COOKIE['youare']=='1'){?>
								<li class="inactive"><a href="addadmin.php">Add Admin</a></li>
								
								
								<?php } ?>
								<li class="inactive"><a href="addreview.php">Add Reviews</a></li>
								<li class="inactive"><a href="about.php">About</a></li>
							</ul>
						</div>
				<?php } ?>
				<?php require_once"../controllers/changePassController.php"; ?>
			<?php if($has_error){
				echo "<div class='GoHomeBtn'>";
				echo "<input type='submit' name='Gohome' value='Back To Login'>";
				echo "</div>";
			} ?>
		</form>
	</header>
</body>

</html>