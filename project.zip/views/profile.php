<?php
$username=$_GET['id'];
require_once "../controllers/searchController.php";

?>

<html>


		
		
	<title>Profile</title>
	
	<head>
		<link rel="stylesheet" type="text/css" href="CSSS/profile.css">
		<script src="https://kit.fontawesome.com/1e099de9d8.js"></script>
	</head>
	
	
	
	
	
		<body>
		<header>
		
		<form  action="" method="POST">
		<?php require_once "../controllers/userCheck.php"?>
			<center>
			<h1>Profile</h1>
			</center>
						
						<div class="button">
							<ul>
							
								<li class="active"><a href="Homepage.php">Home</a></li>
								<li class="inactive"><a href="movies.php">Movies</a></li>
								
								<li class="inactive"><a href="intheater.php">In Theaters</a></li>
								<li class="inactive"><a href="comingsoon.php">Coming soon</a></li>
								
								
								<li class="inactive"><a href="bestmovie.php">Best Movies</a></li>
								<?php
								if($_COOKIE['youare']=='1'){?>
								<li class="inactive"><a href="addadmin.php">Add Admin</a></li>
								<?php } ?>
								<li class="inactive"><a href="addreview.php">Add Reviews</a></li>
								<li class="inactive"><a href="about.php">About</a></li>
							</ul>
						</div>
						

			<div class="personalinfo">
				<ul>
					<li class="personal">Personal Information</li>
					
				</ul>
				<?php if($user==$username ){?>
				<div class="chngpass">
				<ul>
					<li class="cpass"><a href="changepass.php?id=<?php echo $user ?>">Change password</a></li>
					<?php
						if($_COOKIE['youare']!='1'){?>
								<li class="fav"><a href="pendingAndFavReview.php?id=<?php echo $user ?>">Favorite Movies</a></li>
					<?php } ?>
					<?php
						if($_COOKIE['youare']=='1'){?>
								<li class="fav"><a href="pendingAndFavReview.php?id=<?php echo $user ?>">Pending Reviews</a></li>
					<?php } ?>
					
				</ul>
				</div>
				
				<?php } ?>
			</div>	

			

			
			<br> <br> <br><br><br> 
			
				
	
		<?php
			$query="SELECT * FROM signup";
			$reviews=get($query);
				
			
			if(mysqli_num_rows($reviews) > 0)
			{
				
				while($rows = mysqli_fetch_assoc($reviews))
				{
					
					
					if($rows['username']==$username){
					
					echo "<div class='point'>";
					echo "<table align='center' border=1 style='border-collapse:collapse; '>";	
			
					echo "<tr>";
					echo "<td  class='name'>"." Name "."</td>";
					echo "<td width='3%'>"."<center>"." : "."</center>"."</td>";
					echo "<td width='60%' class='disname'>".$rows["name"]."</td>.</div>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"." Username  "."</td>";
					echo "<td>"."<center>"." : "."</center>"."</td>";
					echo "<td  class='disname'>".$rows["username"]."</td>";
					echo "</tr>";
					if($user==$username){
					echo "<tr>";
					echo "<td class='name'>"." Email  "."</td>";
					echo "<td>"."<center>"." : "."</center>"."</td>";
					echo "<td class='disname'>".$rows["email"]."</td>";
					echo "</tr>";
					}
					echo "<tr>";
					echo "<td class='name'>"." PresentAddress  "."</td>";
					echo "<td>"."<center>"." : "."</center>"."</td>";
					echo "<td class='disname'>".$rows["praddress"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"." PermanentAddress "."</td>";
					echo "<td>"."<center>"." : "."</center>"."</td>";
					echo "<td class='disname'>".$rows["peaddress"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"." City "."</td>";
					echo "<td>"."<center>"." : "."</center>"."</td>";
					echo "<td class='disname'>".$rows["city"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"." State "."</td>";
					echo "<td>"."<center>"." : "."</center>"."</td>";
					echo "<td class='disname'>".$rows["state"]."</td>";
					echo "</tr>";
					
					echo "<tr>";
					echo "<td class='name'>"." Zip "."</td>";
					echo "<td>"."<center>"." : "."</center>"."</td>";
					echo "<td class='disname'>".$rows["zip"]."</td>";
					echo "</tr>";
					if($user==$username){
					echo "<tr>";
					echo "<td class='name'>"." Phone "."</td>";
					echo "<td>"."<center>"." : "."</center>"."</td>";
					echo "<td class='disname'>".$rows["phone"]."</td>";
					echo "</tr>";
					}
					echo "</table>";
					
					echo "</div>";
					}
					
				}
			}
		
		?>
		
	
		
		
	
				
				
				
		
		
		</form>
		<center>&copy; Copyright 2020 Movie review site</center>
		</header>
	</body>



</html>