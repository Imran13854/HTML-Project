<?php
	require_once "../controllers/searchController.php";
	$moviename=$_GET['q'];
	
?>
<html>

	<title>Movies,Reviews,News</title>
	
	<head>
		
		<link rel="stylesheet" type="text/css" href="CSSS/search.css">
		
		<script src="https://kit.fontawesome.com/1e099de9d8.js"></script>
	</head>
	
	
	
	
	<body>
	<header>
		
		<form action="" method="post">
		<?php require_once "../controllers/userCheck.php"?>
		<center>
		<h1>Movie Search</h1>
		</center>		
			
			<div class="button">
				
							<ul>
							
								
								<li class="active"><a href="Homepage.php">Home</a></li>
								<li class="inactive"><a href="movies.php">Movies</a></li>
								<li class="inactive"><a href="news.php">News</a></li>
								<li class="inactive"><a href="intheater.php">In Theaters</a></li>
								<li class="inactive"><a href="comingsoon.php">Coming soon</a></li>
								<li class="inactive"><a href="bestmovie.php">Best Movies</a></li>
								
								<?php
								if($_COOKIE['youare']=='1'){?>
								<li class="inactive"><a href="addadmin.php">Add Admin</a></li>
								
								
								<?php } ?>
								<li class="inactive"><a href="addreview.php">Add Reviews</a></li>
								<li class="inactive"><a href="about.php">About</a></li>
							</ul>
						</div>
			
			
			<br> <br> <br><br><br> 
			<br> <br> <br><br><br> 
			
		<?php
		
		
		
			$count=0;
			$qury="SELECT id,name FROM addreview WHERE name LIKE '%$moviename%'";
			$reviews=get($qury);
			
			echo "<div  style='margin-left:180px; margin-top:40px;  width:900px;' class='point'>";
			echo "<table align='center'  style=' border-collapse:collapse; '>";
			echo "<tr>"."<td>"."<h2>"."Found Results:"."</h2>"."</td>"."</tr>";
			if(mysqli_num_rows($reviews) > 0)
			{
				
				while($row = mysqli_fetch_assoc($reviews))
				{
					
					$count+=1;
					$id=$row["id"];
					
					echo "<td  align='left' width='60%' class='mname'>"."<a href='readreview.php?mid=$id'>".$row["name"]."</a>"."</td>";
					
					echo "</tr>";
					$noreview=0;
					
					
					
					
				}
			}
			else{
				echo "<tr>";
					echo "<td  align='left' width='60%' class='mname'>"."No movie review found"."</td>"."</div>";
					echo "</tr>";
			}
			
			echo "</table>";
					
		echo "</div>";
			
		
		
		?>
			
				
			
		
	
		</form>
		</header>
	</body>



</html>