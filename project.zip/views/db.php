<html>
<head>
<style>
#movies {
  position: absolute;
  font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 18%;
  top:12%;
  left:82%;
  overflow:hidden;
    overflow-y: auto;
    height: 300px;
	display:block;
   
}

#movies td {
  border: 1px solid #ddd;
  padding: 8px;
  padding-right:65px;
}

#movies tr td:nth-child(even){background-color: #f2f2f2;}


#movies tr:hover {background-color: #ddd;}

#movies tr {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
</style>
</head>
<body>
<?php
$key = $_GET['key'];
require_once"../models/db_connect.php";


$query ="SELECT name,id FROM addreview WHERE name LIKE '%$key%' ";
$result=get($query);


echo "<table id='movies'>";
if(mysqli_num_rows($result) > 0)
{
while($row = mysqli_fetch_assoc($result))
{
	echo "<tr>";
	
	echo "<td ><a href='readreview.php?mid=".$row["id"]."'>".$row["name"]."</a></td>";
	echo "</tr>";															
}
}
else{
	echo "<tr>";
	
	echo "<td >Sorry,No Movie Found</td>";
	echo "</tr>";
}
echo "</table>";



?>
</body>
</html>