<?php

	require_once "../controllers/searchController.php";

	$username=$_GET['id'];
	
?>
<html>

	<title>Movies,Reviews,News</title>
	
	<head>
		
		<link rel="stylesheet" type="text/css" href="CSSS/profile.css">
		<link rel="stylesheet" type="text/css" href="CSSS/pendingandfavmovie.css">
		<link rel="stylesheet" type="text/css" href="CSSS/commonCategory.css">
		<script src="https://kit.fontawesome.com/1e099de9d8.js"></script>
	</head>
	
	
	
	
	<body>
	<header>
		
		<form action="" method="post">
		<?php require_once "../controllers/userCheck.php"?>
		<center>
		<h1>Movie review site</h1>
		</center>		
			
			<div class="button">
				
							<ul>
							
								
								<li class="active"><a href="Homepage.php">Home</a></li>
								<li class="inactive"><a href="movies.php">Movies</a></li>
								
								<li class="inactive"><a href="intheater.php">In Theaters</a></li>
								<li class="inactive"><a href="comingsoon.php">Coming soon</a></li>
								<li class="inactive"><a href="bestmovie.php">Best Movies</a></li>
								
								<?php
								if($_COOKIE['youare']=='1'){?>
								<li class="inactive"><a href="addadmin.php">Add Admin</a></li>
								
								
								<?php } ?>
								<li class="inactive"><a href="addreview.php">Add Reviews</a></li>
								<li class="inactive"><a href="about.php">About</a></li>
							</ul>
						</div>
			
			
			<br> <br> <br><br><br> 
			
		<?php
		if($_COOKIE['youare']=='1')
		{
			$query="SELECT * FROM pendingreview";
			$review=get($query);
			$count=0;	
			echo "<div style='margin-left:180px; margin-top:40px;  width:900px;' class='point'>";
			echo "<table align='center' border=1 style='border-collapse:collapse; '>";
			echo "<center>"."<h2 style='color:red;'>"."Pending Reviews"."</h2>"."</center>";
			if(mysqli_num_rows($review) > 0)
			{
				
				while($row = mysqli_fetch_assoc($review))
				{
					
					
					$id=$row["id"];
					$uploader=$row["uploader"];
					$count+=1;
					echo "<td  align='center' width='60%' class='mname'>"."$count".". "."<a href='pendingreview.php?mid=$id'>".$row["name"]."</a>"." Movie review was uploaded by "."<a href='profile.php?id=$uploader'>".$uploader."</a>".
					" At ".$row["date"]."&nbsp".$row["time"]."</td>";
					echo "</tr>";
					
					
					
				}
			}
			else{
				echo "<tr>";
				echo "<td  align='center' width='60%' class='mname'>"."No Pending movie review found"."</td>"."</div>";
				echo "</tr>";
			}
		echo "</table>";
		echo "</div>";
		}
		
		if($_COOKIE['youare']!='1'){
			$count=0;
			$qury="SELECT * FROM favmovie ORDER BY fid DESC";
			$reviews=get($qury);
			
					
				
			if(mysqli_num_rows($reviews) > 0)
			{
				echo "<div  style='margin-left:180px; margin-top:40px;  width:900px;' class='point'>";
				echo "<table align='center' border=1 style=' border-collapse:collapse; '>";
				
					echo "<tr>";
					echo "<td align='center' class='mname'>"."Movies"."</td>";
					echo "<td align='center' class='mname'>"."Update Time"."</td>";
					echo "</tr>";
				while($row = mysqli_fetch_assoc($reviews))
				{
					
					
					if($row['musername']==$username){
					
					$fid=$row["fmid"];
			
					$count+=1;
			
					echo "<tr>";
					echo "<td style='padding-right:90px;' align='left' width='60%' class='mname'>"."$count".". "."<a href='readreview.php?mid=$fid'>".$row["mname"]."</a>"."</td>";
					echo "<td class='mname'>".$row["date"]." On ".$row["time"]."</td>";
					echo "</tr>";
					$noreview=0;
					
					
					}
					
					
				}
			}
			else{
							$noreview=1;
				}
			if($noreview==1){
				echo "<div  style='margin-left:180px; margin-top:40px;  width:900px;' class='point'>";
			echo "<table align='center' border=1 style=' border-collapse:collapse; '>";
				
					echo "<tr>";
					echo "<td align='center' class='mname'>"."No favorite movie review found"."</td>";
					
					echo "</tr>";
			}
			
			echo "</table>";
					
		echo "</div>";
			
			
			
		}
		
		
		?>
			
				
			
		
	
		</form>
		</header>
	</body>



</html>