<?php 
require_once"../controllers/readReviewController.php";
require_once "../controllers/searchController.php";
?>
<html>

		
	<title>Movies</title>
	
	<head>
		<link rel="stylesheet" type="text/css" href="CSSS/readreview.css">
		<link rel="stylesheet" type="text/css" href="CSSS/commonCategory.css">
		<script src="https://kit.fontawesome.com/1e099de9d8.js"></script>
	</head>
	
	
	
	
	
		<body>
		<header>
	
		
		<form  action="" method="POST">
		<?php require_once "../controllers/userCheck.php"?>
			<center>
			<h1>Reviews</h1>
			</center>
						
						<div class="button">
							<ul>
							
								<li class="inactive"><a href="Homepage.php">Home</a></li>
								<li class="active"><a href="movies.php">Movies</a></li>
								
								<li class="inactive"><a href="intheater.php">In Theaters</a></li>
								<li class="inactive"><a href="comingsoon.php">Coming soon</a></li>
								<li class="inactive"><a href="bestmovie.php">Best Movies</a></li>
								<?php
								if($_COOKIE['youare']=='1'){?>
								<li class="inactive"><a href="addadmin.php">Add Admin</a></li>
								
								
								<?php } ?>
								<li class="inactive"><a href="addreview.php">Add Reviews</a></li>
								<li class="inactive"><a href="about.php">About</a></li>
							</ul>
						</div>
						
				
	<?php require_once "category.php" ?>
		
		<br> <br> <br> <br> <br> <br> <br> <br>
		<br> <br>
		
		<?php require_once"commonSingleReviewRead.php"?>
				
		
		</form>
		<center>&copy; Copyright 2020 Movie review site</center>
		</header>
	</body>



</html>