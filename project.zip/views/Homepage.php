<?php
	require_once "../controllers/searchController.php";
?>


<html>

	<title>Movies,Reviews,News</title>
	
	<head>
		<link rel="stylesheet" type="text/css" href="CSSS/home.css">
		
		
		<script src="https://kit.fontawesome.com/1e099de9d8.js"></script>
	</head>
	
	
	
	
	<body>
	<header>
		
		<form action="" method="post">
		<?php require_once "../controllers/userCheck.php"?>
		<center>
		<h1>Movie review site</h1>
		</center>		
			
			<div class="button">
				
							<ul>
							
								
								<li  class="active"> <a href="Homepage.php">Home</a></li>
								<li  class="inactive"><a href="movies.php">Movies</a></li>
								
								<li  class="inactive"><a href="intheater.php">In Theaters</a></li>
								<li  class="inactive"><a href="comingsoon.php">Coming soon</a></li>
								<li  class="inactive"><a href="bestmovie.php">Best Movies</a></li>
								
								<?php
								if($_COOKIE['youare']=='1'){?>
								<li  class="inactive"><a href="addadmin.php">Add Admin</a></li>
								
								
								<?php } ?>
								<li  class="inactive"><a href="addreview.php">Add Reviews</a></li>
								<li  class="inactive"><a href="about.php">About</a></li>
							</ul>
						</div>
			
				
			<div class="spotlight-box">
			
					<center><h3>In Spotlight</h3></center>
				
			</div>
				
			<?php require_once "../controllers/homeController.php"?>
		
	
		</form>
		<center>&copy; Copyright 2020 Movie review site</center>
		</header>
	</body>



</html>