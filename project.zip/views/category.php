<div class="tabpos">
							<table bgcolor="#004EA8">
								<tr>
									<td width="2000">
										<div>
											<ul class="cat">
												<li class="H"><a href="allreview.php?mid=0">Hindi</a></li>
												<li class="H"><a href="allreview.php?mid=1">English</a></li>
												<li class="H"><a href="allreview.php?mid=2">Tamil</a></li>
												<li class="H"><a href="allreview.php?mid=3">Telugu</a></li>
												<li class="H"><a href="allreview.php?mid=4">Malayalam</a></li>
												<li class="H"><a href="allreview.php?mid=5">Kannada</a></li>
												<li class="H"><a href="allreview.php?mid=6">Korean</a></li>
												<li class="H"><a href="allreview.php?mid=7">Spanish</a></li>
												<li class="H"><a href="allreview.php?mid=8">Indonesia</a></li>
												
												
											</ul>
											
										</div>
									</td>
								</tr>
							</table>
						</div>					