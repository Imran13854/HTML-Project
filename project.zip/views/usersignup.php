<?php
	
	require "../models/db_connect.php";
	
?>
<html>
	<body>
		<?php
		$err_fname="";
		$fname="";
		$err_lname="";
		$lname="";
		$err_uname="";
		$uname="";
		$err_email="";
		$email="";
		$err_address1="";
		$address1="";
		$err_address2="";
		$address2="";
		$err_city="";
		$city="";
		$err_state="";
		$state="";
		$err_zip="";
		$zip="";
		$err_phone="";
		$phone="";
		$err_pass="";
		$pass="";
		$err_confpass="";
		$confpass="";
		$has_error=false;
		
		
		if(isset($_POST['login']))
		{
			
			if(empty($_POST['fname']))
			{
				$err_fname="*First Name Required";
				$has_error=true;
			}
			else
			{			
				$fname=htmlspecialchars($_POST['fname']);
				
			}
			if(empty($_POST['lname']))
			{
				$err_lname="*Last Name Required";
				$has_error=true;
				
			}
			else
			{			
				$lname=htmlspecialchars($_POST['lname']);
				
			}
			if(empty($_POST['uname']))
			{
				$err_uname="*Username Required";
				$has_error=true;
			}
			else
			{			
				$uname=htmlspecialchars($_POST['uname']);
				
			}
			if(empty($_POST['email']))
			{
				$err_email="*E-mail Required";
				$has_error=true;
			}
			else
			{
				$email=htmlspecialchars($_POST['email']);
				if (!filter_var($email, FILTER_VALIDATE_EMAIL))
				{
					$err_email = "Invalid email format";
					$has_error=true;
				}
				else
				{
					
				}
			}
			if(empty($_POST['address1']))
			{
				$err_address1="*Address Required";
				$has_error=true;
			}
			else
			{
				$address1=htmlspecialchars($_POST['address1']);
				
			}
			if(empty($_POST['address2']))
			{
				$err_address2="*Address Required";
				$has_error=true;
			}
			else
			{
				$address2=htmlspecialchars($_POST['address2']);
				
			}
			if(empty($_POST['city']))
			{
				$err_city="*City Required";
				$has_error=true;
			}
			else
			{
				$city=htmlspecialchars($_POST['city']);
				
			}
			if(empty($_POST['state']))
			{
				$err_state="*State Required";
				$has_error=true;
			}
			else
			{
				$state=htmlspecialchars($_POST['state']);
				
			}
			if(empty($_POST['zip']))
			{
				$err_zip="*Zip code Required";
				$has_error=true;
			}
			else
			{
				$zip=htmlspecialchars($_POST['zip']);
				
			}
			if (empty($_POST['phone']))
			{
				$err_phone="*Phone number Required";
				$has_error=true;
			}
			else
			{
				$phone=htmlspecialchars($_POST['phone']);
				$phone=$_POST['phone'];
				
				if (strlen($phone)==11){
				
					
				}
				else{
					$err_phone="*Invalid Phone number";
					$has_error=true;
				}
			}
			
			if(empty($_POST['pass']))
			{
				$err_pass="*Password Required";
				$has_error=true;
			}
			else
			{
				$pass=htmlspecialchars($_POST['pass']);
				$pass=$_POST['pass'];
				
				if (strlen($pass)>=8){
				
					
				}
				else{
					$err_pass="*Password must contain more than 8 char or digits";
					$has_error=true;
				}
			}
			if(empty($_POST['confpass']))
			{
				$err_confpass="*Password Required";
				$has_error=true;
			}
			else
			{
				$confpass=htmlspecialchars($_POST['confpass']);
				$confpass=$_POST['confpass'];
				
				if ($confpass == $pass){
				
					
				}
				else{
					$err_confpass="*Password doesn't match";
					$has_error=true;
				}
				
			}
			
			if(!$has_error){
				$pass=md5($pass);
			 $query="INSERT INTO signup (name, username, email, praddress, peaddress, city, state, zip, phone) 
			 VALUES ('$fname', '$uname', '$email', '$address1', '$address2', '$city', '$state', '$zip', '$phone')";
			 $data="INSERT INTO login (username, password) 
			 VALUES ('$uname', '$pass')";
			$sign=execute($query);
			$log=execute($data);
			
			
			header("Location:login.php");
			}
			
			
		}
		?>
	
		<title>Signup</title>
		<head>
			<link rel="stylesheet" type="text/css" href="CSSS/adminsignup.css">
	    </head>
		<body>
			<header>
					<div class="login-box">
					<img src="Photo/avaterlogo3.png" class="avatar">
						
						<h1>Signup Here</h1>
							<form method="POST" action="">
								<table>
									<tr>
										<td>
											<p>First Name</p><small><span style="color:red"><?php echo $err_fname;?></span></small>
											<input type="text" name="fname" value="<?php echo $fname;?>" placeholder="Enter Name name">
											
											<p>Username</p><small><span style="color:red"><?php echo $err_uname;?></span></small>
											<input type="text" name="uname" value="<?php echo $uname;?>" placeholder="Enter Username">
											
											<p>Present Address</p><small><span style="color:red"><?php echo $err_address1;?></span></small>
											<input type="text" name="address1" value="<?php echo $address1;?>" placeholder="Enter Present Address">
											
											<p>City</p><small><span style="color:red"><?php echo $err_city;?></span></small>
											<input type="text" name="city" value="<?php echo $city;?>" placeholder="Enter City">
											
											<p>Zip Code</p><small><span style="color:red"><?php echo $err_zip;?></span></small>
											<input type="text" name="zip" value="<?php echo $zip;?>" placeholder="Enter Zip code">
											
											<p>Password</p><small><span style="color:red"><?php echo $err_pass;?></span></small>
											<input type="password" name="pass" value="<?php echo $pass;?>" placeholder="Enter Password">
										
										</td>
										<td>
											&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp 
											&nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp
										</td>
										<td>
											<p>Last Name</p><small><span style="color:red"><?php echo $err_lname;?></span></small>
											<input type="text" name="lname" value="<?php echo $lname;?>" placeholder="Enter Last name">
											
											<p>E-mail</p><small><span style="color:red"><?php echo $err_email;?></span></small>
											<input type="text" name="email" value="<?php echo $email;?>" placeholder="Enter E-mail">
											
											<p>Permanet Address</p><small><span style="color:red"><?php echo $err_address2;?></span></small>
											<input type="text" name="address2" value="<?php echo $address2;?>" placeholder="Enter Permanet Address">
											
											<p>State</p><small><span style="color:red"><?php echo $err_state;?></span></small>
											<input type="text" name="state" value="<?php echo $state;?>" placeholder="Enter State">
											
											<p>Phone Number</p><small><span style="color:red"><?php echo $err_phone;?></span></small>
											<input type="text" name="phone" value="<?php echo $phone;?>" placeholder="Enter Phone Number">
											
											<p>Confirm Password</p><small><span style="color:red"><?php echo $err_confpass;?></span></small>
											<input type="password" name="confpass" value="<?php echo $confpass;?>" placeholder="Re-Enter Password">
										</td>
									</tr>
								</table>
								<center>
									
								</center>
								<center><input type="submit" name="login" value="Login">
								<br><a href="login.php">Already have an account</a>
								</center>
						</form>
							
					</div>
			</header>
		</body>
</html>