-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 15, 2020 at 09:13 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `addreview`
--

CREATE TABLE `addreview` (
  `uploader` varchar(50) NOT NULL,
  `mid` int(11) NOT NULL,
  `id` int(10) NOT NULL,
  `name` varchar(5000) NOT NULL,
  `director` varchar(5000) NOT NULL,
  `cast` varchar(5000) NOT NULL,
  `month` varchar(500) NOT NULL,
  `day` int(5) NOT NULL,
  `year` int(10) NOT NULL,
  `category` varchar(500) NOT NULL,
  `genre` varchar(100) NOT NULL,
  `imdb` float NOT NULL,
  `img` blob NOT NULL,
  `description` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `addreview`
--

INSERT INTO `addreview` (`uploader`, `mid`, `id`, `name`, `director`, `cast`, `month`, `day`, `year`, `category`, `genre`, `imdb`, `img`, `description`) VALUES
('Bob123', 6, 0, 'Burning', 'Chang Dong Lee', 'Ah-In Yoo, Steven Yeun, Jong-seo Jun', 'May', 17, 2018, 'Korean', 'Thriller', 7.6, 0x6275726e696e672e6a7067, 'Human are called best creature of earth for intelligence and communication style. To do communication among human being, Speech is the most common and logical mode. For many decades researchers are trying to make machine intelligent like human. Intelligence of machine can be described as “A machine or system that can perceive it’s surrounding with sensors and take action with actuators to achieve goals successfully in an uncertain environment”. Researchers find many ways to make machine smarter. Some of them are already implemented and some are on processing stage. To make machine smarter, researchers include “Understanding Human Speech”. Speech recognition machine is already part of our daily life but in limited commands. Why do we need machine that can understand our speech, right? There is a term called “Human Computer Interaction” which refers how efficiently, easily and reliably we can make contract with machines. We usually use touch screens, keyboards or mouse to interact with machine. What about machine can understand us and do work accordingly. Speech recognition machine allows us to talk with them, control device via speech, Enables hand free technology etc. Speech recognition has become challenging and interesting problem because human speech is continuous and hard to organize in correct way by machine. After realizing all benefit and future challenges we choose this research topic to contribute our knowledge. After reading several research papers we have noticed that an important application of speech recognition is missing. In health care we can use speech recognition machine. Our focus is to make speech recognition machine better than before. \r\nSpeech is the most common way to communicate among human being and the most easiest and natural form of exchanging information in short period of time. Communication with computer is called human computer interaction. We use different approaches to communicate with computer or system. Communication by speech with computer is interesting and challenging too. Speech recognition can be described as the method of converting speech signal to a sequence of words (speech to text) by means Algorithm implemented as a computer program. Speech processing is one the subpart of signal processing. The goal of speech recognition system is to develop techniques that take human speech as input, simulate the input (it can understand our spoken language) and work accordingly (the system can react appropriately to the spoken words and convert the speech into another medium such as text).During 20th century researchers have been researching ways and means to make computers able to record and interpret and understand human speech.'),
('Imran', 1, 59, 'Memories of Murder', 'Bong Joon-ho', 'Song Kang Ho,Kim Sung Kyung, Kim Roi Ha', 'September', 15, 2010, 'English', 'Action', 9.1, 0x6275726e696e672e6a7067, ' This is a wondrous little film, if a bit confusing. The summary is simple: a woman re-appears a year after her death without memory of her husband and child, who are the first to find her sitting alone near a railroad track. The movie unfolds to reveal the entire story  and is well worth watching.\r\n'),
('Imran', 2, 60, 'Memories of Murder', 'Bong Joon-ho', 'Song Kang Ho,Kim Sung Kyung, Kim Roi Ha', 'January', 2, 2020, 'Tamil', 'Action,Romantic', 9.1, 0x6d656d6f726965736f666d75726465722e6a7067, 'This is a wondrous little film, if a bit confusing. The summary is simple: a woman re-appears a year after her death without memory of her husband and child, who are the first to find her sitting alone  near a railroad track. The movie unfolds to  reveal the entire story and is well worth watching .\r\n\r\n\r\nTo be enjoyed here are the actors , who do very good jobs of portraying their parts. Cliché? Hardly . the story is unique , the characters well- portrayed . the “penguin” scene is quit humorous . a perfect film?  No  . But it’s a cut above typical love stories.  Does it fall short  in spots and leave the user scratching one’s head at times ? yes but it  also brings laughter ,appreciation , one significantly unexpected “wince” moment  and a few tears. It is unfortunate that some are so jaded and demanding in their film watching that they can no longer enjoy a simple bit of story– telling.\r\n\r\n\r\nFor the romantics, for those who enjoy a decent story (if a bit odd) , for  those who appreciate a twist  or two during the recounting of events, this is a quite a nice experience . you may have to watch the ending twice to get the all-too-quick plot twist , but it’s easy enough to hit replay. All in all, worth watching.  \r\n'),
('Imran', 6, 61, 'Burning', 'Bong Joon-ho', 'Song Kang Ho,Kim Sung Kyung, Kim Roi Ha', 'May', 2, 2018, 'Korean', 'Thriller', 9.1, 0x6275726e696e672e6a7067, 'This is a wondrous little film, if a bit confusing. The summary is simple: a woman re-appears a year after her death without memory of her husband and child, who are the first to find her sitting alone  near a railroad track. The movie unfolds to  reveal the entire story and is well worth watching .\r\n\r\n\r\nTo be enjoyed here are the actors , who do very good jobs of portraying their parts. Cliché? Hardly . the story is unique , the characters well- portrayed . the “penguin” scene is quit humorous . a perfect film?  No  . But it’s a cut above typical love stories.  Does it fall short  in spots and leave the user scratching one’s head at times ? yes but it  also brings laughter ,appreciation , one significantly unexpected “wince” moment  and a few tears. It is unfortunate that some are so jaded and demanding in their film watching that they can no longer enjoy a simple bit of story– telling.\r\n\r\n\r\nFor the romantics, for those who enjoy a decent story (if a bit odd) , for  those who appreciate a twist  or two during the recounting of events, this is a quite a nice experience . you may have to watch the ending twice to get the all-too-quick plot twist , but it’s easy enough to hit replay. All in all, worth watching.  \r\n\r\nAn interesting modern take on the invisible man concept in this twisted mind game nightmare yet it comes with the lack of the invisible man  presence! An abuse wife escapes her narcissist and sadistic husband to her friend house only to know after a couple of weeks that he committed suicide , in what seems like a happy ending for her turns out to  be hell as she feels her husband’s presence around here almost everywhere which leads her to suspect that  he’s still alive and won’t let her go this easy.\r\nSo far the idea sounds interesting but for a general thriller , not revival of a classic, believe the plot should’ve been approached with more of a homage to the classic adaption. I know the idea of taking chemical potions to become invisible is over used but a plot mix between modern technology and past methods would’ve been a better choice, I already have couple  of ideas on how to do so just by writing this. \r\nElisabeth Moss carries the movie well, yet the movie feels more like “The Invisible Man’s Wife “ story more than being the Invisible man story! Practically almost the whole movie is focused on the wife , her mantel suffering and what she’s through, you can barley see/sense any predictable like you can almost see through but it’s a nice piece of a (general thriller) for the most part.\r\n'),
('Imran', 6, 62, 'Be with You ', 'Lee Jang Hoon', 'So Ji-Sub, Son Ye-Jin', 'March', 14, 2018, 'Korean', 'Romantic', 9.1, 0x626577697468796f752e6a7067, 'This is a wondrous little film, if a bit confusing. The summary is simple: a woman re-appears a year after her death without memory of her husband and child, who are the first to find her sitting alone  near a railroad track. The movie unfolds to  reveal the entire story and is well worth watching .\r\n\r\n\r\nTo be enjoyed here are the actors , who do very good jobs of portraying their parts. Cliché? Hardly . the story is unique , the characters well- portrayed . the “penguin” scene is quit humorous . a perfect film?  No  . But it’s a cut above typical love stories.  Does it fall short  in spots and leave the user scratching one’s head at times ? yes but it  also brings laughter ,appreciation , one significantly unexpected “wince” moment  and a few tears. It is unfortunate that some are so jaded and demanding in their film watching that they can no longer enjoy a simple bit of story– telling.\r\n\r\n\r\nFor the romantics, for those who enjoy a decent story (if a bit odd) , for  those who appreciate a twist  or two during the recounting of events, this is a quite a nice experience . you may have to watch the ending twice to get the all-too-quick plot twist , but it’s easy enough to hit replay. All in all, worth watching.\r\n'),
('Imran', 1, 63, 'The Invisible Man', 'Leign Whannel', 'Elisabeth Moss, Aldis Hodge,Stom Reid', 'February', 27, 2020, 'English', 'Sci-fi', 8.9, 0x746865696e76697369626c656d616e2e6a7067, 'An interesting modern take on the invisible man concept in this twisted mind game nightmare yet it comes with the lack of the invisible man  presence! An abuse wife escapes her narcissist and sadistic husband to her friend house only to know after a couple of weeks that he committed suicide , in what seems like a happy ending for her turns out to  be hell as she feels her husband’s presence around here almost everywhere which leads her to suspect that  he’s still alive and won’t let her go this easy.\r\nSo far the idea sounds interesting but for a general thriller , not revival of a classic, believe the plot should’ve been approached with more of a homage to the classic adaption. I know the idea of taking chemical potions to become invisible is over used but a plot mix between modern technology and past methods would’ve been a better choice, I already have couple  of ideas on how to do so just by writing this. \r\nElisabeth Moss carries the movie well, yet the movie feels more like “The Invisible Man’s Wife “ story more than being the Invisible man story! Practically almost the whole movie is focused on the wife , her mantel suffering and what she’s through, you can barley see/sense any predictable like you can almost see through but it’s a nice piece of a (general thriller) for the most part.\r\n'),
('Imran', 6, 64, 'Snowpiercer', 'Bong Joon-ho', 'Chirs Evans, Song Kang-Ho,Tilda Swinton, Jamie Bell', 'July', 29, 2013, 'Korean', 'Drama,Action', 8.3, 0x536e6f77706965726365725f706f737465722e6a7067, 'I noticed that people seemed to rate this film either quite high or extremely low and reading the reviews, I can see that those who rated high and those who rated low were watching completely different movies.\r\nThe apocalypse has already happened , with the plant transformed into a frozen block of  ice over the next twenty years. The last dregs of mankind sought refuge abroad an ever moving train barrelling through the icy landscape . the central  conflict of “snowpiercer” deals, of course , with a major class struggle , with most of the refugees hunkering in the ghettoized tail section of the train . \r\n The privileged  few live in the front cars and ragged masses congregating in the rear are sick of the oppression , and rebellion begins to foment. I know the idea of taking chemical potions to become invisible is over used but a plot mix between modern technology and past methods would’ve been a better choice, I already have couple  of ideas on how to do so just by writing this. Almost immediately, this feels like a futuristic retelling of drama set on a train bound for Aischwitz.\r\n'),
('Imran', 1, 65, 'John Wick', 'Chad Stehelski', 'Keanu Reeves, Michel Nyqvyit,  Allfy Allen', 'December', 29, 2014, 'English', 'Action', 8.3, 0x4a6f686e5f5769636b5f546561736572506f737465722e6a7067, 'Assassin John Wick is referred to as baba yaga in this third chapter , suggesting that he is in fact , a supernatural being ;his ability to evade death, appear and disappear like ninja from a Godfrey Ho film, and in my opinion . unfortunately , Wick’s invincibility means that the many action scenes in parabellum are largely devoid of excitement , only outcome begin that Wick is still alive and all of his enemies are dead . \r\nChapter 2 set things up for s potentially entertaining part three ,ending with John Wick on the run , hunted by the word’s top assassins , all keen to collect the bounty on his head . this film should have been a whole lot of outrageously OTT comic book fun , with an array if bizarre and unique killers, each with their own distinctive look and style ; it certainly starts off on the right foot with a few of fun fight scenes , but it all goes downhill rapidly after that .\r\nA pack of trained dogs easily outshine their human co-stars in one skirmish, a fight involving samurai swords and motorbikes blatantly   borrows from the villainess  and a battle between wick and mark DACASCOS in a glass room is frustratingly tedious. I blame director Chad Stahelski. Who hasn’t progressed as a film-maker since part one, content to simply give fans more of the several stories from the roof of a building . enough already !!!\r\n'),
('Imran', 2, 66, 'Memories of Murder', 'Bong Joon-ho', 'Song Kang Ho,Kim Sung Kyung, Kim Roi Ha', 'February', 14, 2013, 'Tamil', 'Action,Romantic', 8.3, 0x6d6f72657468616e626c75652e6a7067, 'jdnjnfj jernjnfjref jnrjfnjrenf jrnefjnrejfn refnjernfr jrefjnrejf jnrfjrnjf'),
('Imran', 4, 76, 'More Than Blue', 'Anthony Russo, Joe Russo', 'tony, hulk,captain', 'February', 12, 2011, 'Malayalam', 'Action,Romantic', 9.1, 0x6d6f72657468616e626c75652e6a7067, 'This is a wondrous little film, if a bit confusing. The summary is simple: a woman re-appears a year after her death without memory of her husband and child, who are the first to find her sitting alone  near a railroad track. The movie unfolds to  reveal the entire story and is well worth watching .\r\n\r\n\r\nTo be enjoyed here are the actors , who do very good jobs of portraying their parts. Cliché? Hardly . the story is unique , the characters well- portrayed . the “penguin” scene is quit humorous . a perfect film?  No  . But it’s a cut above typical love stories.  Does it fall short  in spots and leave the user scratching one’s head at times ? yes but it  also brings laughter ,appreciation , one significantly unexpected “wince” moment  and a few tears. It is unfortunate that some are so jaded and demanding in their film watching that they can no longer enjoy a simple bit of story– telling.\r\n\r\n\r\nFor the romantics, for those who enjoy a decent story (if a bit odd) , for  those who appreciate a twist  or two during the recounting of events, this is a quite a nice experience . you may have to watch the ending twice to get the all-too-quick plot twist , but it’s easy enough to hit replay. All in all, worth watching.    \r\n'),
('Imran', 1, 77, 'Arjun Reddy', 'Anthony Russo, Joe Russo', 'tony, hulk,captain', 'October', 17, 1982, 'English', 'Thriller', 9, 0x61726a756e72656464792e6a7067, 'It looks as if the filmmakers realized that the public was sick of  certain movies . most movies nowadays are full of wire work, sci-fi, etc . often topped with icing made of needless or predictable background stories that add nothing . for example the beautiful girlfriend who gives the moral speeches or the troubled teenage daughter , who aren’t present here.  \r\nJohn Wick is referred to as Baba  in this  chapter , suggesting that he is in fact , a supernatural being ;his ability to evade death, appear and disappear like ninja from a Godfrey Ho film, and in my opinion .\r\nNothing of that is in John Wick adds hardly a story , no character or background , no misplaced drama , no misplaced humor and not too much eye candy , nothing of that what john wick offer is action , action and more action. In fact , it is one long action scene , with some lines and deliver. While delivering they made it is not a problem  . the directors promise action and delivered . look good and convincing , without trying to be more , and they’re smart enough to give the movie a satisfying beginning and ending.\r\nAnd for those who clam that Keanu Reeves is a horrible actor. You are right . but his blank expression is perfect for this movie . leave the acting to the bed guys and delicious guest part for Willem Dafoe.\r\n'),
('Imran', 1, 78, 'Memories of Murder', 'Bong Joon-ho', 'Ah-In Yoo, Steven Yeun, Jong-seo Jun', 'October', 15, 2008, 'English', 'Action', 8.9, 0x536e6f77706965726365725f706f737465722e6a7067, 'wejrnjnr rnjrnfjef jrenfjernf jrfnjrefnjerf jrfnjerfjer jrfnjrefj rnfjerfjer jrfjrefnjerf jnfjrefnerjf jrnfjrenfrej jrfnjernfjrn jrjrjfrejf jrnfjrefnj jrfnjernf rjfnjrefn'),
('Imran', 0, 79, 'Avengers Infinity', 'Bong Joon-ho', 'Ah-In Yoo, Steven Yeun, Jong-seo Jun', 'November', 17, 2010, 'Hindi', 'Action', 8.9, 0x746865696e76697369626c656d616e2e6a7067, 'jfrbf hferhfbherfb hrbfherfh herfherf hrfherf herfbherf herbhfbr hrbherbf rhfbherfb ehrfbherfb'),
('Imran', 3, 80, 'Avengers Infinity', 'Anthony Russo, Joe Russo', 'Song Kang Ho,Kim Sung Kyung, Kim Roi Ha', 'February', 1, 2024, 'Telugu', 'Thriller', 8.9, 0x6d6f72657468616e626c75652e6a7067, 'ljnfjrenfj erfkejrfnkejrf erjfernfer fernfjernf rjfjernfr ferjnf r ferfjer rfjrefnr ref ernf'),
('Imran', 1, 81, 'Avengers Infinity', 'Anthony Russo, Joe Russo', 'Ah-In Yoo, Steven Yeun, Jong-seo Jun', 'September', 15, 2012, 'English', 'Action,Romantic', 9.1, 0x6d6f72657468616e626c75652e6a7067, 'wrfjrwnfjrnfjrenfrejf rfnjernfnerjf erjfnerjnfjref jfjrenfjer fjhhdefuhwruifriufjurifujeri jernfgergn rgjnegjr jngjnerjgn ejgnojengjrtng imran'),
('Imran', 4, 82, 'Premam', 'imran', 'Ah-In Yoo, Steven Yeun, Jong-seo Jun', 'September', 14, 2019, 'Malayalam', 'Action,Romantic', 8.9, 0x7072656d616d2e6a7067, 'I m remarkably stingy with my 10/10 ratings. I’ll be the first person to acknowledge this. Of the roughly 2600 titles I’ve rated on here, only 34 have a 10. Parasite is one of them. if this isn’t a masterpiece, then I don’t know what is.\r\nI’m going to keep it vague on the plot-front, because I didn’t know anything about it going in, and was really excited to see it progress and unfold in satisfying , unexpected ways. \r\nWhat I will say is that this film, more than just about any other I’ve seen, put me through so many different emotional states during its 132-minute runtime, and did so without ever feeling muddled tonally inconsistent. Parts of this movie were hilarious. Parts were heartbreaking.  other parts of this I’ve felt this close to the edge of my seat since the final season of breaking bad, way back. \r\nI’m stumped to come up with any flaw for this movie. and sure, I’ve seen many movies from every single member of its cast. All the characters are understandable and sympathetic. It’s extremely entertaining, thoroughly moving in so close to technically perfect. there’s a ton of social commentary and some heavy themes to chew on once the movie’s over.\r\nCatch this one when you can and believe the hype. Joon-Ho Bong has made many great films, but this even manages to stand head and shoulders above all the others.\r\nWhen it comes time to consider what the best film of the 2010s was, this one will surely be up there.\r\n'),
('Bob123', 5, 83, 'Beasts Clawing', 'Bong Joon-ho', 'Kwon Sang-woo,Le Bo-young,Le beom-so', 'July', 15, 2018, 'Kannada', 'Action,Romantic', 9.1, 0x4265617374732d436c6177696e672d333030783230302e6a7067, 'the movie is very awesome. Thriller very realistic .;kjhf fekrjnf rfjnrjkwefnjref refnjernfjnrfer fkjenrfjkrenfjre erfjkernfkjnerjfn erfker ferjkfnjrenf rfernfjrenfjrenfjnrejfnrejnfjernfjrenfjrenfjernjfnerjfnre'),
('Bob123', 0, 84, 'Bahubali', 'SS Rajmouli', 'Prabash,Anuska Shetty', 'March', 11, 2017, 'Hindi', 'Action', 9.1, 0x426161687562616c695f5468655f426567696e6e696e675f4d6f7669655f506f737465722e6a7067, 'Bahubali is a historical movie created by SS rajmouli. A very interesting and war related movie. wbdfwjf wnfjnwrfk jnfjkenrjf refnjernfjer jernfkjrnejfn ekrjfnkjernfkj erfjrenjf erkfnjernfj erfkjernfnerjf erfkjernfkjre erfkjrefj eefkjerkjf erfjkernjfn erfkjer'),
('Imran', 0, 85, 'Memories of Murder', 'Bong Joon-ho', 'Kwon Sang-woo,Le Bo-young,Le beom-so', 'October', 13, 2012, 'Hindi', 'Thriller', 8.9, 0x4a6f686e5f5769636b5f546561736572506f737465722e6a7067, 'jdsjnckjwndfkj jfkjwnfkjrwf rf kjrenfjnref rjefnjernf erjnfjernf jrefnjernf frjnerjfnrej erfnjrenrf jernfjrenf refjerkfnjernf'),
('Imran', 1, 87, 'Avengers Infinity', 'Anthony Russo, Joe Russo', 'Robert Downey Jr. ,Chris Hemsworth, Mark Ruffalo, Chris Evans, Scarlett Johansson', 'April', 18, 2019, 'English', 'Sci-fi', 9.1, 0x6176656e6765722e6a7067, 'I consider myself a big comic book marvel fan. My favourite films from the franchise so far, are Cap. America: Winter soldier and Thor: Ragnarok. As this movie was directed by same guys as winter soldier and civil war, I went into this movie with sky-high expectations. \r\nI am going to keep this brief: avengers: infinity war blew me away! If I should mention just one thing that really amazed me was the character of Thanos. He is so well developed and makes for a super interesting and complex villain. As an audience, we  are actually capable of sympathizing with a guy, who wants to kill off half of the universe. It’s not about power or dominance. It’s about preserving life in universe with finite resource – a goal with leads him (and the avengers) into several interesting moral dilemmas.\r\nI give this movie my highest recommendations. It’s a must-see for anyone with just a remote interest in the franchise.\r\n'),
('Imran', 6, 88, 'Parasite', 'Bong Joon-ho', 'Kwon Sang-woo,Le Bo-young,Le beom-so', 'March', 4, 2019, 'Korean', 'Thriller', 9.1, 0x70617261736974652e6a7067, 'I m remarkably stingy with my 10/10 ratings. I’ll be the first person to acknowledge this. Of the roughly 2600 titles I’ve rated on here, only 34 have a 10. Parasite is one of them. if this isn’t a masterpiece, then I don’t know what is.\r\nI’m going to keep it vague on the plot-front, because I didn’t know anything about it going in, and was really excited to see it progress and unfold in satisfying , unexpected ways. \r\nWhat I will say is that this film, more than just about any other I’ve seen, put me through so many different emotional states during its 132-minute runtime, and did so without ever feeling muddled tonally inconsistent. Parts of this movie were hilarious. Parts were heartbreaking.  other parts of this I’ve felt this close to the edge of my seat since the final season of breaking bad, way back. \r\nI’m stumped to come up with any flaw for this movie. and sure, I’ve seen many movies from every single member of its cast. All the characters are understandable and sympathetic. It’s extremely entertaining, thoroughly moving in so close to technically perfect. there’s a ton of social commentary and some heavy themes to chew on once the movie’s over.\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `comingsoon`
--

CREATE TABLE `comingsoon` (
  `mid` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `name` varchar(5000) NOT NULL,
  `director` varchar(5000) NOT NULL,
  `cast` varchar(5000) NOT NULL,
  `month` varchar(500) NOT NULL,
  `day` int(20) NOT NULL,
  `year` int(20) NOT NULL,
  `category` varchar(500) NOT NULL,
  `genre` varchar(100) NOT NULL,
  `img` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comingsoon`
--

INSERT INTO `comingsoon` (`mid`, `id`, `name`, `director`, `cast`, `month`, `day`, `year`, `category`, `genre`, `img`) VALUES
(5, 1, 'Memories of Murder', 'Anthony Russo, Joe Russo', 'Song Kang Ho,Kim Sung Kyung, Kim Roi Ha', 'August', 18, 2023, 'Kannada', 'Drama,Action', 0x4a6f686e5f5769636b5f546561736572506f737465722e6a7067),
(1, 2, 'Avengers Infinity', 'Won Tae-Yeon', 'Kwon Sang-woo,Le Bo-young,Le beom-so', 'October', 14, 2020, 'English', 'Action,Comedy', 0x4265617374732d436c6177696e672d333030783230302e6a7067),
(2, 3, 'hello', 'Lee Jang Hoon', 'Salman Dulaqur', 'August', 11, 2022, 'Tamil', 'Action,Romantic', 0x6d6f72657468616e626c75652e6a7067),
(4, 4, 'Avengers Infinity', 'Won Tae-Yeon', 'Song Kang Ho,Kim Sung Kyung, Kim Roi Ha', 'May', 15, 2025, 'Malayalam', 'Biography', 0x746865696e76697369626c656d616e2e6a7067),
(1, 5, 'Avengers Infinity', 'Lee Jang Hoon', 'Salman Dulaqur', 'April', 13, 2029, 'English', 'Biography', 0x6275726e696e672e6a7067),
(2, 8, 'Burning', 'Bong Joon-ho', 'Robert Downey Jr. ,Chris Hemsworth, Mark Ruffalo, Chris Evans, Scarlett Johansson', 'February', 13, 2030, 'Tamil', 'Romantic,Comedy', 0x6275726e696e672e6a7067),
(1, 9, 'Memories of Murder', 'Won Tae-Yeon', 'Salman Dulaqur', 'May', 3, 2030, 'English', 'Action,Romantic', 0x4a6f686e5f5769636b5f546561736572506f737465722e6a7067),
(1, 11, 'Dark', 'Won Tae-Yeon', 'Robert Downey Jr. ,Chris Hemsworth, Mark Ruffalo, Chris Evans, Scarlett Johansson', 'March', 14, 2020, 'English', 'Action', 0x536e6f77706965726365725f706f737465722e6a7067);

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `mid` int(30) NOT NULL,
  `id` int(10) NOT NULL,
  `comment` mediumtext NOT NULL,
  `user` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`mid`, `id`, `comment`, `user`) VALUES
(64, 18, 'nice movie review...', 'Bob123'),
(83, 19, 'nice movie man.....', 'Bob123'),
(59, 20, 'nice review....', 'Bob123'),
(88, 21, 'nice movie..\r\n', 'Raj');

-- --------------------------------------------------------

--
-- Table structure for table `favmovie`
--

CREATE TABLE `favmovie` (
  `fid` int(20) NOT NULL,
  `musername` varchar(50) NOT NULL,
  `fmid` int(25) NOT NULL,
  `mname` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `favmovie`
--

INSERT INTO `favmovie` (`fid`, `musername`, `fmid`, `mname`, `date`, `time`) VALUES
(276, 'Raj', 88, 'Parasite', '2020-05-13', '15:57:05'),
(277, 'Raj', 80, 'Avengers Infinity', '2020-05-13', '15:58:41'),
(278, 'Bob123', 87, 'Avengers Infinity', '2020-05-13', '15:59:03'),
(279, 'Bob123', 81, 'Avengers Infinity', '2020-05-13', '15:59:29'),
(280, 'Raj', 61, 'Burning', '2020-05-13', '18:16:23'),
(281, 'Bob123', 82, 'Premam', '2020-05-14', '11:42:40'),
(282, 'Bob123', 61, 'Burning', '2020-05-15', '13:12:34');

-- --------------------------------------------------------

--
-- Table structure for table `intheater`
--

CREATE TABLE `intheater` (
  `mid` int(50) NOT NULL,
  `id` int(50) NOT NULL,
  `name` varchar(5000) NOT NULL,
  `director` varchar(5000) NOT NULL,
  `cast` varchar(5000) NOT NULL,
  `month` varchar(500) NOT NULL,
  `day` int(20) NOT NULL,
  `year` int(20) NOT NULL,
  `category` varchar(500) NOT NULL,
  `genre` varchar(100) NOT NULL,
  `img` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `intheater`
--

INSERT INTO `intheater` (`mid`, `id`, `name`, `director`, `cast`, `month`, `day`, `year`, `category`, `genre`, `img`) VALUES
(0, 1, 'Dark', 'Bong Joon-ho', 'Ah-In Yoo, Steven Yeun, Jong-seo Jun', 'February', 3, 0, 'Germany', 'Action', 0x536e6f77706965726365725f706f737465722e6a7067);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(10) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`) VALUES
(1, 'Abir', 'bae5e3208a3c700e3db642b6631e95b9'),
(1, 'Anek', 'f75f4af93a22f869762a67d87fd58582'),
(0, 'Bob123', 'd48674762fc5870e3cb492d69d6caac8'),
(1, 'foysal', '1bbd886460827015e5d605ed44252251'),
(1, 'Imran', 'c4ca4238a0b923820dcc509a6f75849b'),
(0, 'Raj', '04ebdcd302cc50454bb2b2eea1dd5532');

-- --------------------------------------------------------

--
-- Table structure for table `pendingreview`
--

CREATE TABLE `pendingreview` (
  `uploader` varchar(50) NOT NULL,
  `mid` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `name` varchar(5000) NOT NULL,
  `director` varchar(5000) NOT NULL,
  `cast` varchar(5000) NOT NULL,
  `month` varchar(500) NOT NULL,
  `day` int(5) NOT NULL,
  `year` int(10) NOT NULL,
  `category` varchar(500) NOT NULL,
  `genre` varchar(100) NOT NULL,
  `imdb` float NOT NULL,
  `img` blob NOT NULL,
  `description` mediumtext NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `name` varchar(50) NOT NULL,
  `username` varchar(25) NOT NULL,
  `email` varchar(30) NOT NULL,
  `praddress` varchar(100) NOT NULL,
  `peaddress` varchar(100) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `zip` int(20) NOT NULL,
  `phone` bigint(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`name`, `username`, `email`, `praddress`, `peaddress`, `city`, `state`, `zip`, `phone`) VALUES
('Abir', 'Abir', 'Abir@gmail.com', 'Dhaka', 'Dhaka', 'Dhaka', 'Dhaka', 1111, 23569745213),
('Anek', 'Anek', 'anek@gmail.com', 'Dhaka', 'Dhaka', 'Dhaka', 'Dhaka', 3233, 32659745123),
('Bob', 'Bob123', 'Bob@gmail.com', 'Washington', 'Washington', 'DC', 'DC', 50230, 52349236101),
('Foysal', 'foysal', 'foysal13854@gmail.com', 'Dhaka', 'Dhaka', 'Dhaka', 'Bangladesh', 1313, 98764523121),
('Imran', 'Imran', 'imran13854@gmail.com', 'kalatiya', 'Kalatia', 'Dhaka', 'Dhaka', 1313, 12345678910),
('Raj', 'Raj', 'Raj@gmail.com', 'Dhaka', 'Dhaka', 'Dhaka', 'Dhaka', 2130, 14253698753);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addreview`
--
ALTER TABLE `addreview`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comingsoon`
--
ALTER TABLE `comingsoon`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `favmovie`
--
ALTER TABLE `favmovie`
  ADD PRIMARY KEY (`fid`);

--
-- Indexes for table `intheater`
--
ALTER TABLE `intheater`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pendingreview`
--
ALTER TABLE `pendingreview`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addreview`
--
ALTER TABLE `addreview`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `comingsoon`
--
ALTER TABLE `comingsoon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `favmovie`
--
ALTER TABLE `favmovie`
  MODIFY `fid` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=283;

--
-- AUTO_INCREMENT for table `intheater`
--
ALTER TABLE `intheater`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pendingreview`
--
ALTER TABLE `pendingreview`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
